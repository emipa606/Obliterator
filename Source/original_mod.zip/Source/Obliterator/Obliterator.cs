﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Verse;

namespace VVO_Obliterator
{
    public class ModExtension_ObliteratorBullet : DefModExtension
    {
        public float destroyBodyPartChance = 0.5f;
    }
}
